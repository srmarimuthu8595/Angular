const express = require("express");
const bodyParser = require("body-parser");
const app = express();

app.use(bodyParser.urlencoded({
    extended: true
  }));
  app.use(bodyParser.json());
app.use(function (req, res, next) {
        res.setHeader('Access-Control-Allow-Origin','*');

    res.setHeader(
        "Access-Control-Allow-Methods",
        "GET, POST, OPTIONS, PUT, PATCH, DELETE"
    );
    res.setHeader(
        "Access-Control-Allow-Headers",
        "X-Requested-With,content-type,__setXHR_"
    );
    res.setHeader("Access-Control-Allow-Credentials", true);
    next();
});
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017";

MongoClient.connect(url, function (err, db) {
    if (err) throw err;
    console.log("Database created!");
    var dbo = db.db("customerDB");
    app.get("/customer", function (req, res) {
        dbo.collection("customer").find({}).toArray(function (err, result) {
            if (err) throw err;
            result.map(a=>delete a["_id"])
            console.log("result sent")
            res.send(result);

        })
    })
    app.post("/addcustomer", function (req, res) {
        dbo.collection("customer").insertOne(req.body, function (err, result) {
            if (err) throw err;
            console.log("1 document inserted");
            res.status(200).send({msg:"success"})
        });
    })
    app.put("/editcustomer", function (req, res) {

        dbo.collection("customer").updateOne({"customerId":req.body.customerId},{$set:req.body}, function (err, result) {
            if (err) throw err;
            console.log("1 document updated");
            res.status(200).send({"msg":"Success"})
        });
    })
    
    app.delete("/deletecustomer/:id", function (req, res) {
        console.log(req.params.id)
        dbo.collection("customer").deleteOne({"customerId":req.params.id}, function (err, result) {
            if (err) throw err;
            console.log("1 document deleted");
            res.status(200).send({"msg":"success"})
        });
    })

});
app.listen(1200, () => {
    console.info("webserver running in 1200");
  });