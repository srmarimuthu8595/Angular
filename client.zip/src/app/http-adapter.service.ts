import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpAdapterService {
public apiBasePath = "http://localhost:1200/"
  constructor(private http: HttpClient ) { }

  public httpPost(params, cbk) {
    this.http.post(this.apiBasePath+params.url, params.data,{observe:"response"})
      .subscribe(
        res => {
          cbk(null, res);
        },
        err => {
          cbk(err, null);
        }
      );
  }

  public httpPut(params, cbk) {
    this.http.put(this.apiBasePath+params.url, params.data,{observe:"response"})
      .subscribe(
        res => {
          cbk(null, res);
        },
        err => {
          cbk(err, null);
        }
      );
  }
  public httpGet(params, cbk) {

    this.http.get(this.apiBasePath+params.url,{observe:"response"})
      .subscribe(
        res => {
          cbk(null, res);
        },
        err => {
          cbk(err, null);
        }
      );
  }

  public httpDelete(params, cbk) {

    this.http.delete(this.apiBasePath+params.url,{observe:"response"})
      .subscribe(
        res => {
          cbk(null, res);
        },
        err => {
          cbk(err, null);
        }
      );
  }
}
