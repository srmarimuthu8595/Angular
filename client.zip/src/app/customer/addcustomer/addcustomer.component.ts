import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-addcustomer',
  templateUrl: './addcustomer.component.html',
  styleUrls: ['./addcustomer.component.scss']
})
export class AddcustomerComponent implements OnInit {

  @Input() customerDetailWindow;
  @Output() closeCustomer = new EventEmitter();
  @Output() addCustomer = new EventEmitter();
  @Input() mode;
  @Input() set currentCusomter(value){
    console.log(value)
    if(value!=undefined && value!={}&&this.mode=="Edit"){
    
      this.customerData.setValue(JSON.parse(JSON.stringify(value)));
      this.customerData.updateValueAndValidity();
    }
  }
  customerData = this.fb.group({
    
    customerId:[''],
    firstName: ['', Validators.required],
    lastName: [''],
    dob: ['', Validators.required],
    phoneNumber: ['', Validators.required],
    address: [''],
    city: ['']
  });
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
  }

  closeWindow() {
    this.customerDetailWindow = false;
    this.closeCustomer.emit(this.customerDetailWindow)
  }
  emitCustomer(){
    this.addCustomer.emit(this.customerData.value)
    this.closeWindow();
  }

}
