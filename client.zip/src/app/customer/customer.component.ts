import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { HttpClient } from '@angular/common/http';
import { HttpAdapterService } from '../http-adapter.service';


@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})
export class CustomerComponent implements OnInit {
  @ViewChild("userTable", { static: false }) userTable: MatTable<any>;
  displayedColumns: string[] = ['name', "dob", "phone", "address", "city", "action"];
  public dataSource: MatTableDataSource<any>;
  public customerDetailWindow;
  public customers = [{
    firstName: "asas",
    lastName: "sadas",
    dob: "sdfds",
    phoneNumber: "sdfsdf",
    address: "sdfdf",
    city: "sddfds"
  }];
  currentCustomer: any;
  mode: string;
  private httpAdapter: HttpAdapterService

  constructor(private http: HttpClient) {
    this.customerDetailWindow = false;
    this.dataSource = new MatTableDataSource(this.customers)
    this.mode = "Add";
    this.currentCustomer = {};
    this.httpAdapter = new HttpAdapterService(this.http);
  }

  ngOnInit() {
    this.getCustomers();
  }

  public getCustomers(){
    var params = {
      url: "customer"
    }
    var self = this;
    self.httpAdapter.httpGet(params, function (err, result) {
      if (err) {
        console.log(err)
      } else {
        console.log(result)
        if(result.status==200 ){
          self.customers = result.body;
          
          self.dataSource = new MatTableDataSource(self.customers);
          self.userTable.renderRows();
        }
      }
    })
  }
  addCustomer(data) {
    var self =this;
    if (self.mode == "Add"){
    var params = {
      url:"addcustomer",
      data:data
    }
      self.httpAdapter.httpPost(params,function(err,result){
        if(!err){
          self.getCustomers()
        }else{
          console.log(err);
        }
      })
    }
      // self.customers.push(data)
    if (self.mode = "Edit") {
      var params = {
        url:"editcustomer",
        data:data
      }
      self.httpAdapter.httpPut(params,function(err,result){
        if(!err){
          self.getCustomers()
        }else{
          console.log(err);
        }
      })
    }
    
  }
  addCustomerDetail() {
    this.customerDetailWindow = true
    this.mode = "Add";
  }

  closeWindow(data) {
    this.customerDetailWindow = data
    }

  editCustomer(data) {
    this.currentCustomer = data;
    this.mode = "Edit";
    this.customerDetailWindow = true;
  }
  deleteCustomer(data) {
   var self = this;
    var params = {
      url:"deletecustomer/"+data.customerId,
      data:data
    }
    self.httpAdapter.httpDelete(params,function(err,result){
      if(!err){
        console.log(result)
        self.getCustomers()
      }else{
        console.log(err);
      }
    })
  
  }
}
